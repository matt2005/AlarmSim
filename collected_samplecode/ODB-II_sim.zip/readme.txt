Folgende Dateien sind in diesem Archiv enthalten:
You'll find the following files in this archive:

MiniSimConfig_DE.exe
-------------------------------------------------------
MINISIM Konfigurationstool in Deutsch
Sie ben�tigen ein OBD2-Interface f�r KWP2000-Fast, das
an den Minisim angeschlossen ist. Beide Schalter m�ssen
auf OFF stehen.

MiniSimConfig_EN.exe
-------------------------------------------------------
MINISIM configuration tool in english
You need an OBD2-interface for KWP2000-Fast connected
to the minisim. Both switches must be in OFF-position.

/avrdude
avrdude.conf
avrdude.exe
libusb0.dll
MINISIM.hex
minisim-mega8.bat
-------------------------------------------------------
Tool zur Programmierung des ATMega8 Flash-Speichers mit
einem AVRDUDE kompatiblen Programmieradapter. Die 
Parameter f�r COM-Port (-P) und Adaptertyp (-c) m�ssen
eventuell angepasst werden.

Tool for programming the ATMega8 flash memory with an
AVRDUDE compatible programmer. You have to change the
parameters for COM-port (-P) and programmer type (-c).

